package com.carlosamaral.auxiliai

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AuxiliaiApplicationTests {

	@Test
	fun contextLoads() {
	}

}
